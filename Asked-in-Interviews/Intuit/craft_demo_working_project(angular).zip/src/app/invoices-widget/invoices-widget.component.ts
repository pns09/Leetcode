import { Component, OnInit } from '@angular/core';
import { invoices } from '../../data/invoices';
import { transactions } from '../../data/transactions';

@Component({
  selector: 'app-invoices-widget',
  templateUrl: './invoices-widget.component.html',
  styleUrls: ['./invoices-widget.component.css'],
})
export class InvoicesWidgetComponent implements OnInit {
  public data: any[] = invoices;
  constructor() {}

  ngOnInit() {
    transactions.forEach((transaction) => {
      invoices.forEach((invoice) => {
        if (invoice.reference_number === transaction.reference_number) {
          invoice.status = 'PAID';
        }
      });
    });
  }
}
