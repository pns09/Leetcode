import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { SummaryWidgetComponent } from './summary-widget/summary-widget.component';
import { InvoicesWidgetComponent } from './invoices-widget/invoices-widget.component';

@NgModule({
  imports: [BrowserModule, FormsModule],
  declarations: [AppComponent, SummaryWidgetComponent, InvoicesWidgetComponent],
  bootstrap: [AppComponent],
})
export class AppModule {}
