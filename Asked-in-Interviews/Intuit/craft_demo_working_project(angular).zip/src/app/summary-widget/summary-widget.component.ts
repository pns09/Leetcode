import { Component, OnInit } from '@angular/core';
import { transactions } from '../../data/transactions';

@Component({
  selector: 'app-summary-widget',
  templateUrl: './summary-widget.component.html',
  styleUrls: ['./summary-widget.component.css'],
})
export class SummaryWidgetComponent implements OnInit {
  public data: any[] = transactions;
  public totalSum: Number = 0;
  public threshold: Number = 500;

  constructor() {}

  ngOnInit() {
    this.data.forEach((item) => {
      this.totalSum += item.monetary;
    });
  }

  getClassName() {
    if (this.totalSum > this.threshold) return 'green';
    else if (this.totalSum >= 0 && this.totalSum <= this.threshold)
      return 'neutral';
    else if (this.totalSum < 0) return 'red';
  }
}
