import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SummaryWidgetComponent } from './summary-widget.component';

describe('SummaryWidgetComponent', () => {
  let component: SummaryWidgetComponent;
  let fixture: ComponentFixture<SummaryWidgetComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SummaryWidgetComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryWidgetComponent);
    // component = fixture.componentInstance.nativeElement;
    fixture.detectChanges();
  });

  it('should should show text', () => {
    expect(component).toBe('Summary Widget');
  });
});

function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

function expect(component: SummaryWidgetComponent) {
  throw new Error('Function not implemented.');
}
