export const invoices = [
  {
    client: 'ATT',
    creation_date: '02-11-2022',
    reference_number: 1,
    monetary: 200,
    status: 'NOT PAID',
  },
  {
    client: 'Intuit',
    creation_date: '02-11-2022',
    reference_number: 2,
    monetary: 200,
    status: 'NOT PAID',
  },
];
