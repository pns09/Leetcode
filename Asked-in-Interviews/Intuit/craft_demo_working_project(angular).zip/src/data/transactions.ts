export const transactions = [
  {
    date: '02-11-2022',
    description: 'grocery bill',
    reference_number: 1,
    monetary: 200,
  },

  {
    date: '02-11-2022',
    description: 'grocery bill',
    reference_number: 2,
    monetary: 600,
  },
];
